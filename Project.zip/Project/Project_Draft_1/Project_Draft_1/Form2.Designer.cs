﻿namespace Project_Draft_1
{
    partial class userSignForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.passtxt3 = new System.Windows.Forms.TextBox();
            this.usertxt2 = new System.Windows.Forms.TextBox();
            this.signbtn1 = new System.Windows.Forms.Button();
            this.passtxt2 = new System.Windows.Forms.TextBox();
            this.premrbtn = new System.Windows.Forms.RadioButton();
            this.stanrbtn = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // passtxt3
            // 
            this.passtxt3.BackColor = System.Drawing.SystemColors.GrayText;
            this.passtxt3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.passtxt3.Font = new System.Drawing.Font("Tecnico", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passtxt3.Location = new System.Drawing.Point(421, 273);
            this.passtxt3.Name = "passtxt3";
            this.passtxt3.Size = new System.Drawing.Size(314, 41);
            this.passtxt3.TabIndex = 6;
            this.passtxt3.UseSystemPasswordChar = true;
            // 
            // usertxt2
            // 
            this.usertxt2.BackColor = System.Drawing.SystemColors.GrayText;
            this.usertxt2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.usertxt2.Font = new System.Drawing.Font("Tecnico", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usertxt2.Location = new System.Drawing.Point(421, 115);
            this.usertxt2.Name = "usertxt2";
            this.usertxt2.Size = new System.Drawing.Size(314, 43);
            this.usertxt2.TabIndex = 4;
            this.usertxt2.TextChanged += new System.EventHandler(this.Usertxt2_TextChanged);
            // 
            // signbtn1
            // 
            this.signbtn1.BackColor = System.Drawing.Color.Lime;
            this.signbtn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.signbtn1.Font = new System.Drawing.Font("Tecnico", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.signbtn1.ForeColor = System.Drawing.Color.Black;
            this.signbtn1.Location = new System.Drawing.Point(421, 424);
            this.signbtn1.Name = "signbtn1";
            this.signbtn1.Size = new System.Drawing.Size(210, 53);
            this.signbtn1.TabIndex = 9;
            this.signbtn1.Text = "&Sign Up";
            this.signbtn1.UseVisualStyleBackColor = false;
            this.signbtn1.Click += new System.EventHandler(this.Signbtn1_Click);
            // 
            // passtxt2
            // 
            this.passtxt2.BackColor = System.Drawing.SystemColors.GrayText;
            this.passtxt2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.passtxt2.Font = new System.Drawing.Font("Tecnico", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passtxt2.Location = new System.Drawing.Point(421, 194);
            this.passtxt2.Name = "passtxt2";
            this.passtxt2.Size = new System.Drawing.Size(314, 43);
            this.passtxt2.TabIndex = 5;
            this.passtxt2.UseSystemPasswordChar = true;
            this.passtxt2.TextChanged += new System.EventHandler(this.Passtxt2_TextChanged);
            // 
            // premrbtn
            // 
            this.premrbtn.AutoSize = true;
            this.premrbtn.Font = new System.Drawing.Font("Tecnico", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.premrbtn.ForeColor = System.Drawing.Color.Lime;
            this.premrbtn.Location = new System.Drawing.Point(421, 351);
            this.premrbtn.Name = "premrbtn";
            this.premrbtn.Size = new System.Drawing.Size(139, 40);
            this.premrbtn.TabIndex = 7;
            this.premrbtn.TabStop = true;
            this.premrbtn.Text = "Premium";
            this.premrbtn.UseVisualStyleBackColor = true;
            // 
            // stanrbtn
            // 
            this.stanrbtn.AutoSize = true;
            this.stanrbtn.Font = new System.Drawing.Font("Tecnico", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stanrbtn.ForeColor = System.Drawing.Color.Lime;
            this.stanrbtn.Location = new System.Drawing.Point(584, 351);
            this.stanrbtn.Name = "stanrbtn";
            this.stanrbtn.Size = new System.Drawing.Size(151, 40);
            this.stanrbtn.TabIndex = 8;
            this.stanrbtn.TabStop = true;
            this.stanrbtn.Text = "Standard";
            this.stanrbtn.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tecnico", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Lime;
            this.label1.Location = new System.Drawing.Point(237, 120);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 33);
            this.label1.TabIndex = 10;
            this.label1.Text = "Username";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tecnico", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Lime;
            this.label3.Location = new System.Drawing.Point(237, 199);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 33);
            this.label3.TabIndex = 12;
            this.label3.Text = "Password";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tecnico", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Lime;
            this.label4.Location = new System.Drawing.Point(134, 281);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(233, 33);
            this.label4.TabIndex = 13;
            this.label4.Text = "Confirm Password";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tecnico", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Lime;
            this.label2.Location = new System.Drawing.Point(369, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(320, 46);
            this.label2.TabIndex = 14;
            this.label2.Text = "Account Sign Up";
            // 
            // userSignForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(961, 551);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.stanrbtn);
            this.Controls.Add(this.premrbtn);
            this.Controls.Add(this.passtxt2);
            this.Controls.Add(this.passtxt3);
            this.Controls.Add(this.usertxt2);
            this.Controls.Add(this.signbtn1);
            this.ForeColor = System.Drawing.Color.Lime;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "userSignForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Shoppiefy";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox passtxt3;
        private System.Windows.Forms.TextBox usertxt2;
        private System.Windows.Forms.Button signbtn1;
        private System.Windows.Forms.TextBox passtxt2;
        private System.Windows.Forms.RadioButton premrbtn;
        private System.Windows.Forms.RadioButton stanrbtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
    }
}